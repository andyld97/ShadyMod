## Shady Mod

This mod adds 15 Scrap-Items to the game (related to [shady]-clan):
- 7 Minecraft Heads
- 8 other Items (one of the item can be also bought in the shop!)

With a Minecraft-Head, you can teleport yourself to the player (only works for our clan members)

When holding a head in your hand, you'll receive a perk!
Perks can be useful but are not always beneficial. Some may be consumed upon use, while others are just for fun.
Some perks are increased if a player holds it's own head!

A big thank you to all team members, and especially to belebt, for her invaluable help with testing!

Currently this mod only adds Scrap-Items, later on I plan to add enemies too!

Be a `great asset` and have fun!

## Changelog

### v1.0.10 (13.06.2025)
- Fix NullRef-Exception
 
### v1.0.9 (02.06.2025)
- Fix NullRef-Exception

### v1.0.8 (21.03.2025)
- Reworked Shady Documents
- Player drops all items when removed from PlayerBox
- Refactoring and small improvements

### v1.0.7 (16.03.2025)
- Fix PlayerBox-Item NetCode

### v1.0.6 (14.03.2025)
- Added new PlayerBox-Item (for player transport)
- Decreased perk range for Enemy-Kill, Enemy-Small-Perk and Enemy-Stunn-Perk
- Small player head will also be scaled small

### v1.0.5 (09.03.2025)
- Added new Robot-Item
- MC Heads won't be destroyed if the target player isn't available
- Fix Donut

### v1.0.4 (08.03.2025)
- Fix Item Activate Handling
- Fix Event Handling
- Fix Teleport-Interaction
- Fix Donut-Interaction
- Fix Heavy Weight (PositionOffset)
- Fix Mod Description

### v1.0.3 (07.03.2025) [HotFix]
- Fix Item Rarity Balancing
- Fix Item Description
- Removed chat log

### v1.0.2 (06.03.2025)
- Reduced chat log
- Small improvements

### v1.0.0 - v1.0.1 (04.03.2025)
- Initial release (feature-complete)
- Fix file structure